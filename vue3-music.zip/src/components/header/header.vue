<template>
  <div class="header">
    <span class="icon"> </span>
    <h1 class="text">Small Music</h1>
    <!-- <router-link></router-link> -->
  </div>
</template>

<script>
export default {};
</script>
 
<style lang="scss" scoped>
.header {
  height: 44px;
  text-align: center;
  color: $color-theme;
  font-size: 0;
  .icon {
    display: inline-block;
    width: 30px;
    height: 32px;
    vertical-align: top;
    margin-top: 6px;
    margin-right: 9px;
    //使用mix-in，把定义的变量添加到这里
    @include bg-image("logo");
    background-size: 30px 32px;
  }
  .text {
    display: inline-block;
    vertical-align: top;
    line-height: 44px;
    font-size: $font-size-large;
  }
}
</style>
